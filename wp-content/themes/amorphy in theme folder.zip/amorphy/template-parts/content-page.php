<article id="post-<?php the_ID(); ?>">
		<?php
		the_content();
		?>
</article><!-- #post-<?php the_ID(); ?> -->
