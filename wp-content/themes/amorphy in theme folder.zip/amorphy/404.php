<?php
get_header();
?>
	<main class="main-content">
  <div class="bg-box1">
  </div>
  <div class="text-center">
    <div class="padding03 bg-back-04">
      <div align="center">
        <h2 class="text06">
          404!
        </h2>
    </div>
  </div>
</main>
<?php
get_footer();
